
import { HttpClient } from '@angular/common/http';
import {Injectable} from '@angular/core'


@Injectable()
export class addTravellerService
{
    API_ENDPOINT_ROOT_URL: string="http://localhost:8084/TravellerSystem/"
    
    LOGGED_IN_USER =null;
    list:any;

    constructor(private http:HttpClient){}

    addTraveller(data){

        let url=`${this.API_ENDPOINT_ROOT_URL}traveller`
        return this.http.post(url,data);
    }

    addScheddule(data)
    {
        let url=`${this.API_ENDPOINT_ROOT_URL}Travellerschedule`
        return this.http.post(url,data);
    }

    listTraveller(){
        let url=`${this.API_ENDPOINT_ROOT_URL}travellerlist`;
        return this.http.get(url);
    }

    allTravellerDetails()
    {
        let url=`${this.API_ENDPOINT_ROOT_URL}travellerschedule1`;
        return this.http.get(url);
    }

    deleteTraveller(id)
    {
        let url=`${this.API_ENDPOINT_ROOT_URL}travellerschedule/${id}`;
        return this.http.delete(url);
    }

    addStatus(data){

        let url=`${this.API_ENDPOINT_ROOT_URL}traveller/`
        return this.http.post(url,data);
    }

    updateTraveller_status(tsid,data)
    {
        let url=`${this.API_ENDPOINT_ROOT_URL}update/${tsid}`;
        return this.http.put(url,data);
    } 

    addTravellerDetails(travellerdata)
    {
        let url=`${this.API_ENDPOINT_ROOT_URL}travellerschedule`;
        return this.http.post(url,travellerdata);
    }

    getTravellerschedule(id)
    {
        let url=`${this.API_ENDPOINT_ROOT_URL}travellerschedule/${id}`;
        return this.http.get(url);

    }
    
    updateSchedule(tsid,data)
    {
        console.log("service "+tsid);
        let url=`${this.API_ENDPOINT_ROOT_URL}update/${tsid}`;
        return this.http.put(url,data);
    }
}