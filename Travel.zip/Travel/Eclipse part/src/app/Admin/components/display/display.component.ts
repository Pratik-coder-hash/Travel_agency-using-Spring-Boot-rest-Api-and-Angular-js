import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { addTravellerService } from '../../services/addTraveller.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  lists: any;
  date: string="";
  status: string="";
  id: any;
  

  data = {
    traveller_date: '',
    starting_time: '',
    ending_time: '',
    
      tnumber: '',
      capacity: '',
   
    
      source: '',
      destination: '',
      cost:''
    
  }

  constructor(private service: addTravellerService, private router:Router) { }

  ngOnInit(): void {

    this.service.allTravellerDetails()
    .subscribe(
      response => {
        
        this.lists=response;
        console.log(this.lists);
      },
      error=>{
        console.log(error)
        
      });
  }

  allTravellerDetails(): void
  {
    this.service.allTravellerDetails()
    .subscribe(
      response => {
        
        this.lists=response;
        console.log(this.lists);
      },
      error=>{
        console.log(error)
        
      });
  }

  deleteTraveller(id)
    {
      this.service.deleteTraveller(id)
      .subscribe(
          response =>{
            console.log("deleted Successfully");
            
          }
         
      )
      this.allTravellerDetails();
    }

    updateStatus(tsid, status1)
    {
      this.status= "Cancelled";

      status1.traveller_status = this.status

      this.service.updateTraveller_status(tsid,status1)
      .subscribe(
        response => {

          console.log("Cancelled Successfully");
          this.allTravellerDetails();

        }
      )
     
     
    }

    updateSchedule(tsid,data){

      this.id = tsid;

      this.data.traveller_date = data.traveller_date;
      
      sessionStorage.setItem("tsid", this.id);

      this.router.navigateByUrl('/updateSchedule');


    }


}
