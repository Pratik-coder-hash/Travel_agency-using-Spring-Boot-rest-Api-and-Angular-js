import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { addTravellerService } from '../../services/addTraveller.service';

@Component({
  selector: 'app-traveller-update',
  templateUrl: './traveller-update.component.html',
  styleUrls: ['./traveller-update.component.css']
})
export class TravellerUpdateComponent implements OnInit {

  id:any;
  lists:any;
  msg: string = "";
  show: any;

  constructor(private service : addTravellerService , private router: Router) { }

  ngOnInit(): void {

    this.id=sessionStorage.getItem("tsid")
    
    this.service.getTravellerschedule(this.id)
    .subscribe(
      response => {
        this.lists=response;
        console.log("Before Respose");
        console.log(this.lists.payload.tnumber);
        
      },
      error=>{
        console.log(error);
      });
  }

  update(data)
  {
    //data.capacity="150";
    this.id=sessionStorage.getItem("tsid");
    console.log("update data"+data);
    
      this.service.updateSchedule(this.id,data)
      .subscribe(
        response => {
          console.log("after Response")
          console.log(response);
          this.msg = "Record Updated Succesfully";
        
        },
        error=>{
          console.log(error)
          
        });
  }

}
