import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TravellerscheduleComponent } from './travellerschedule.component';

describe('TravellerscheduleComponent', () => {
  let component: TravellerscheduleComponent;
  let fixture: ComponentFixture<TravellerscheduleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TravellerscheduleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TravellerscheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
