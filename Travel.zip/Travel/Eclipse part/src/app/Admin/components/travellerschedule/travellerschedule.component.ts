import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { addTravellerService } from '../../services/addTraveller.service';

@Component({
  selector: 'app-travellerschedule',
  templateUrl: './travellerschedule.component.html',
  styleUrls: ['./travellerschedule.component.css']
})
export class TravellerscheduleComponent implements OnInit {

  
  message: string = "";
  list: any;
  msg: string = "";
  show : any;

  constructor(private service : addTravellerService, private router: Router) { }

  ngOnInit(): void {

    this.service.listTraveller()
      .subscribe(
        response => {
          
          this.list = response;
          console.log(this.list);
        }
      )
  }

  TravellerSchedule = {
    traveller_date: '',
    starting_time: '',
    ending_time: '',
    
      tnumber: '',
      capacity: '',
   
    
      source: '',
      destination: '',
      cost:''
    
  }

  addDetails(TravellerSchedule): void {
    
    this.TravellerSchedule.traveller_date = TravellerSchedule.traveller_date;
    this.TravellerSchedule.capacity = TravellerSchedule.capacity;
    this.TravellerSchedule.ending_time = TravellerSchedule.ending_time;
    this.TravellerSchedule.starting_time = TravellerSchedule.starting_time;
    this.TravellerSchedule.tnumber = TravellerSchedule.tnumber;
    this.TravellerSchedule.source = TravellerSchedule.source;
    this.TravellerSchedule.destination = TravellerSchedule.destination;
    this.TravellerSchedule.cost = 
    TravellerSchedule.cost;


this.service.addTravellerDetails(this.TravellerSchedule)
.subscribe(
  response => {
    
    console.warn(this.TravellerSchedule)

    console.log(response)
    this.msg="Traveller Schedule added Successfully";
    this.router.navigateByUrl('/listofTraveller');
  },
  error => {
    console.log(error);
    this.msg="Error in adding Traveller";
  }
)

}


  

}
