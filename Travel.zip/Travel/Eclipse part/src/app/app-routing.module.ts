import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplayComponent } from './Admin/components/display/display.component';
import { HomeComponent } from './Admin/components/home/home.component';
import { TravellerUpdateComponent } from './Admin/components/traveller-update/traveller-update.component';
import { TravellerscheduleComponent } from './Admin/components/travellerschedule/travellerschedule.component';
import { ContactComponent } from './User/components/contact/contact.component';
import { LoginComponent } from './User/components/login/login.component';
import { SearchlistComponent } from './User/components/searchlist/searchlist.component';
import { SearchtravellerComponent } from './User/components/searchtraveller/searchtraveller.component';
import { TravellerDetailsComponent } from './User/components/traveller-details/traveller-details.component';
import { UserDetailsComponent } from './User/components/user-details/user-details.component';
import { UserhomeComponent } from './User/components/userhome/userhome.component';
import { ViewComponent } from './User/components/view/view.component';

const routes: Routes = [

  {path: 'adminhome', component: HomeComponent},
  {path: 'updateSchedule', component: TravellerUpdateComponent},
  {path: 'contact', component: ContactComponent},
  {path: 'userhome', component: UserhomeComponent },
  {path: 'login', component: LoginComponent},
  {path: 'Details', component: TravellerDetailsComponent},
  {path: 'Search' , component: SearchtravellerComponent},
  {path: 'searchlist',component: SearchlistComponent},
  {path: 'user', component: UserDetailsComponent},
  {path: 'listofTraveller' , component: DisplayComponent},
  {path: 'addTraveller', component: TravellerscheduleComponent},
  {path: 'view', component: ViewComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }

export const routingComponents= [

  TravellerUpdateComponent, HomeComponent, ContactComponent, UserhomeComponent, LoginComponent, 
  SearchlistComponent, TravellerDetailsComponent, SearchtravellerComponent, UserDetailsComponent,
  DisplayComponent, TravellerscheduleComponent, ViewComponent



]
