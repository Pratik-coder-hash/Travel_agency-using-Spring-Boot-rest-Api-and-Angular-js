import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit  {
  title = 'travelapp';
  loggedinuser:any;
  router:Router;

  ngOnInit(): void {
    this.loggedinuser = sessionStorage.getItem("username");
  }

    logout()
    {
      sessionStorage.removeItem("username");
      sessionStorage.clear();
      this.router.navigateByUrl('/userhome')

      console.log("hiii");
    }
}
