
import { HttpClient } from '@angular/common//http';
import {Injectable} from '@angular/core'


@Injectable()
export class LoginService
{

    API_ENDPOINT_ROOT_URL: string="http://localhost:8084/TravellerSystem/"
    
    LOGGED_IN_USER =null;
    list:any;
    details:any;
    passengers:any;
    
    constructor(private http :HttpClient){}

    Authentication(mob_no:string, password:string):any
    {
        let url=`${this.API_ENDPOINT_ROOT_URL}authorization/${mob_no}/${password}`;
        return this.http.get(url).toPromise();
    }

    searchtraveller(source:string, destination:string, date:string)
    {
        let url=`${this.API_ENDPOINT_ROOT_URL}Searchtraveller/${source}/${destination}/${date}`;
        return this.http.get(url);
    }

    Addpassenger(data)
    {
        let url=`${this.API_ENDPOINT_ROOT_URL}Addpassenger/`;
        return this.http.post(url,data);
    }

    getPassengers()
    {
        let url=`${this.API_ENDPOINT_ROOT_URL}Getallpassenger/`;
        return this.http.get(url);
    }


    Add_user_details(data)
    {
        let url=`${this.API_ENDPOINT_ROOT_URL}UserRegistration/`;
        return this.http.post(url,data);
    }

    Addcredentials(data)
    {
        let url=`${this.API_ENDPOINT_ROOT_URL}Credentails/`;
        return this.http.post(url,data);
    }
}
