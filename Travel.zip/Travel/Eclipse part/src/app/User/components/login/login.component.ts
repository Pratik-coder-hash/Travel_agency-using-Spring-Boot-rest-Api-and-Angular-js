import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../../services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent  {

  loggedinuser= null;

  show= false;

  message:string= "";

  payload: any;


  constructor( private service : LoginService, private router : Router) { }


  validatation(mob_no:string, password:string)
  {
    this.loggedinuser = this.service.Authentication(mob_no, password)

    .then(response=>{

      if(response.payload!=null)
      {
        this.toggleFunction();
       
        console.warn("username=" +mob_no)
        sessionStorage.setItem('username', mob_no);

        if(mob_no=='admin')
        {
          this.router.navigateByUrl('/adminhome')
        }
        else{
          this.router.navigateByUrl('/Search');
        }
        
        
        
      }
      else
      {
        this.message="Login Fail";
        this.router.navigateByUrl('/login');
      }
    }
    )
    .catch(error=>{

      console.log("login fail");
      console.log(error);
    })
  }
 
  
  toggleFunction()   //hide the button
  {
    this.show = true;
  }


}
