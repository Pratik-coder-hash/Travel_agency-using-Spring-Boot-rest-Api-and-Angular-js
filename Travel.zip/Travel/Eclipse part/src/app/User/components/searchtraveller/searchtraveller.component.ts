import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../../services/login.service';

@Component({
  selector: 'app-searchtraveller',
  templateUrl: './searchtraveller.component.html',
  styleUrls: ['./searchtraveller.component.css']
})
export class SearchtravellerComponent implements OnInit {

  list:any;
   trxid:any;
   demo:any;

  constructor( private service : LoginService, private router: Router) { }

  ngOnInit(): void {

    this.trxid =  sessionStorage.getItem("trx_id");
  }

  Search(data)
    {
      console.log(" in first  search function");
      
      this.service.searchtraveller(data.source, data.destination, data.traveller_date)
       .subscribe(
      response => {

        console.log("in the search function");
        console.log(response);

        this.service.list=response;
        console.log("service=" +this.service.list);
        this.router.navigateByUrl('/searchlist');

      },
      
      error=>{
        console.log(error);
      });
      
    }

}
