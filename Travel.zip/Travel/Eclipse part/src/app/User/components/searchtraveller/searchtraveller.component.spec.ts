import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchtravellerComponent } from './searchtraveller.component';

describe('SearchtravellerComponent', () => {
  let component: SearchtravellerComponent;
  let fixture: ComponentFixture<SearchtravellerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchtravellerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchtravellerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
