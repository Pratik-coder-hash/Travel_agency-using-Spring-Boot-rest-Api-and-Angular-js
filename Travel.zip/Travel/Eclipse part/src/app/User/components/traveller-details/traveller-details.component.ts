import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../../services/login.service';

@Component({
  selector: 'app-traveller-details',
  templateUrl: './traveller-details.component.html',
  styleUrls: ['./traveller-details.component.css']
})
export class TravellerDetailsComponent implements OnInit {

  msg: string;

  details: any;

  list: any;

  storage: any;

  show= true;

  charge: any;

  passengers: Array<Object>=[];

  count: any;



  constructor( private service : LoginService, private router : Router) { }

  ngOnInit(): void {

    this.details=this.service.details;

    console.warn(this.details.tnumber)

    this.storage=sessionStorage.getItem('username');

    console.log("session="+this.storage);

    this.charge=this.details.cost;
  }

  AddPassenger(passenger)
   {
      passenger.username =  this.storage;
      this.passengers.push({name:passenger.name,  age:passenger.age,  mobile_no:passenger.mobile_no});

      this.service.passengers = this.passengers;

      console.log("passenger "+this.passengers)
        
      this.service.Addpassenger(passenger)
     .subscribe(
      response => {
        
        console.warn(response)
        
        console.log(response)
        this.msg="Passenger  added successfully";

      },
      error => {
        console.log(error);
        this.msg="Error while adding passenger";
      }
    )
     alert("Passenger added");
   }


   Displaypassengers()
   {
    
    console.warn(this.passengers)
     this.toggleDiv();
   }

   
   view()
   {
    console.warn(this.passengers)
    this.router.navigateByUrl('/view')
   }

   toggleDiv(){
      this.show = !this.show;
   }

}
