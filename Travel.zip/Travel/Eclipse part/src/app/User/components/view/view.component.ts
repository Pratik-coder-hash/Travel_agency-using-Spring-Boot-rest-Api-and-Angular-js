import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../../services/login.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  passengers:any;
  //passengers : Array<Object>=[]

  constructor( private service : LoginService, private router : Router ) { }

  ngOnInit(): void {
    
    this.passengers = this.service.passengers;
    console.log("details" +this.passengers)
  }

}
