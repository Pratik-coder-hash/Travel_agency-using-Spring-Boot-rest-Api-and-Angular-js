import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../../services/login.service';

@Component({
  selector: 'app-searchlist',
  templateUrl: './searchlist.component.html',
  styleUrls: ['./searchlist.component.css']
})
export class SearchlistComponent implements OnInit {

  msg:string;
  list:any;
  tsid:any;

  constructor( private service : LoginService, private router : Router) { }

  ngOnInit(): void {

    
    this.list= this.service.list;
    console.warn(this.list)
    
    //this.msg= this.list.tsid
    //console.log(this.msg)

  }

  Getdetails(data)
    {
      this.service.details= data;
      this.router.navigateByUrl('/Details');

    }

}
