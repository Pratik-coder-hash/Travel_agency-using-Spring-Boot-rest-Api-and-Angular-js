import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../../services/login.service';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {

  msg:any;

  UserCredential={

    mobile_no:'',
    password:'',
    role:"user",
  }

  user={
    first_name:'',
    last_name:'',
    email:'',
    mobile_no:"",
    gender:'',
    city:'',
    state:'',
    password:''
  }


  constructor( private service : LoginService, private router : Router) { }

  ngOnInit(): void {
  }

  Add_user_details(data)
  {

    console.log(data);

     this.service.Add_user_details(data)
     .subscribe(
      response => {

        console.log(response)
        this.msg="Registration Successful!"
        
        
      },
      error => {
        console.log(error);
        
      }
     )

     this.UserCredential.password= data.password;
     this.UserCredential.mobile_no= data.mobile_no;

     this.service.Addcredentials(this.UserCredential)
     .subscribe(
      response => {
        
        console.log(response)
        
      },
      error => {
        console.log(error);
        
      })
  }


}
