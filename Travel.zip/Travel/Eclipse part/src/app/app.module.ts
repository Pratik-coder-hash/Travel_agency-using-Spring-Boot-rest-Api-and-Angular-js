import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HomeComponent } from './Admin/components/home/home.component';
import { TravellerscheduleComponent } from './Admin/components/travellerschedule/travellerschedule.component';
import { TravellerUpdateComponent } from './Admin/components/traveller-update/traveller-update.component';
import { DisplayComponent } from './Admin/components/display/display.component';
import { addTravellerService } from './Admin/services/addTraveller.service';

import { FormsModule } from '@angular/forms';
import { LoginComponent } from './User/components/login/login.component';
import { SearchlistComponent } from './User/components/searchlist/searchlist.component';
import { SearchtravellerComponent } from './User/components/searchtraveller/searchtraveller.component';
import { TravellerDetailsComponent } from './User/components/traveller-details/traveller-details.component';
import { UserDetailsComponent } from './User/components/user-details/user-details.component';
import { UserhomeComponent } from './User/components/userhome/userhome.component';
import { LoginService } from './User/services/login.service';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ViewComponent } from './User/components/view/view.component';

@NgModule({

  declarations: [
    AppComponent,
    DisplayComponent,
    HomeComponent,
    TravellerscheduleComponent,
    TravellerUpdateComponent,
    LoginComponent,
    SearchlistComponent,
    SearchtravellerComponent,
    TravellerDetailsComponent,
    UserDetailsComponent,
    UserhomeComponent,
    ViewComponent
  ],
  
  imports: [
    BrowserModule,
    AppRoutingModule,
    CommonModule,
    FormsModule,
    HttpClientModule
  ],

  providers: [addTravellerService, LoginService],

  bootstrap: [AppComponent]
  
})

export class AppModule { }
