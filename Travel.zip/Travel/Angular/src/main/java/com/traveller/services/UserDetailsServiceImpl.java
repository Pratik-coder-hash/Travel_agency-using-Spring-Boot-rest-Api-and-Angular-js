package com.traveller.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.traveller.daos.UserDetailsDao;
import com.traveller.pojos.UserDetails;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private UserDetailsDao dao;
	
	@Override
	public void addUser(UserDetails ud) {
		dao.save(ud);
		
	}

}
