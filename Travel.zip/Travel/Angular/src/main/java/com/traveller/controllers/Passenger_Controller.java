package com.traveller.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.traveller.pojos.Passenger;
import com.traveller.pojos.Response;
import com.traveller.services.PassengerService;

@RestController
@CrossOrigin(value="*")
public class Passenger_Controller {

	@Autowired
	private PassengerService service;
	
	@PostMapping("/Addpassenger")
	public Response addPass(@RequestBody Passenger pass) {
		try
		{
			service.addPassenger(pass);
			return new Response("Success",200,"Passenger added successfully");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return new Response("FAILED",200,"Passenger could not be Added") ;
			
		}
	}
	
	@GetMapping("/get/{id}")
	public Passenger GetPassenger(@PathVariable int id)
	{
		return service.getPassenger(id);
	}
	
	@GetMapping("/Getallpassenger")
	public List<Passenger> getAllPassenger()
	{
		return service.getPassengers();
	}
}
