package com.traveller.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.traveller.daos.TravellerDao;
import com.traveller.pojos.Traveller;

@Service
public class TravellerServiceImpl implements TravellerService {

	@Autowired
	private TravellerDao dao;
	
	@Override
	public void add(Traveller air) {
		
		dao.save(air);
		
	}

	@Override
	public void delete(int acid) {
		dao.deleteById(acid);
	}

	@Override
	public Traveller getTraveller(int tid) {
		Optional<Traveller> optional=dao.findById(tid);
		
		if(optional.isPresent())
		{
			return optional.get();
		}	
				
		return null;
	}

	@Override
	public List<Traveller> getAllTraveller() {
		
		return dao.findAll();
	}

	@Override
	public List<String> tList() {
		
		return dao.getNumber();
	}
	
	
}
