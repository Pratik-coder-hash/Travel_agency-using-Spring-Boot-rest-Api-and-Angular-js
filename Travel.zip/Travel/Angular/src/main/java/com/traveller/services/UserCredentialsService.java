package com.traveller.services;

import com.traveller.pojos.UserCredentials;

public interface UserCredentialsService {

	public void addCredentials(UserCredentials user);
	public UserCredentials authenticate(String mobile_no,String password);
}
