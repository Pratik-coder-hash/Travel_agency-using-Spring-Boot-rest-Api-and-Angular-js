package com.traveller.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.traveller.pojos.TravellerSchedule;
import com.traveller.pojos.Response;
import com.traveller.services.TravellerScheduleService;

@RestController
@CrossOrigin(allowedHeaders="*")
public class Traveller_ScheduleController {
	

	@Autowired
	private TravellerScheduleService service;
	
	@PostMapping("/travellerschedule")
	public Response addTraveller(@RequestBody TravellerSchedule schedule)
	{
		try
		{
			service.addTravellerSchedule(schedule);
			return new Response("SUCCESS",200,"Traveller Schedule added successfully");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return new Response("Failed",400,"Traveller Schedule could not be Added");
			
		}
		
	}
	

	@DeleteMapping("/travellerschedule/{id}")
	public String deleteTraveller(@PathVariable("id") int t_id)
	{
		try
		{
			service.deleteTravellerSchedule(t_id);
			return "Traveller Schedule removed successfully";
		}
		catch(Exception e)
		{
			return "could not remove traveller Schedule";	
		}
		
	}
	
	@GetMapping("/travellerschedule/{id}")
	public Response gettravellerById(@PathVariable("id") int t_id)
	{
		try
		{
			TravellerSchedule temp=service.getTravellerSchedule(t_id);
			return new Response("successful", 200, temp);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return new Response("failed", 400, null);			
		}		
	}
	
	@GetMapping("/travellerschedule1")
	public List<TravellerSchedule> getAllTraveller()
	{
		return service.getAllSchedule();
	}
	
	
	@PutMapping("/update/{tsid}")
	public TravellerSchedule changetravellerStatus(@RequestBody TravellerSchedule sc,@PathVariable("tsid") int tsid)
	{
		
			return service.updateStatus(tsid, sc);

	}
	
	@GetMapping("/Searchtraveller/{source}/{destination}/{date}")
	public ArrayList<TravellerSchedule> Search(@PathVariable("source") String source, @PathVariable("destination") String destination,@PathVariable("date") String date)
	{
		return service.Search(source, destination, date);
	}
 
	
}
