package com.traveller.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.traveller.daos.PassengerDao;
import com.traveller.pojos.Passenger;

@Service
public class PassengerServiceImpl implements PassengerService{

	@Autowired
	private PassengerDao dao;
	
	@Override
	public void addPassenger(Passenger pass) {
		 dao.save(pass);
	}

	@Override
	public List<Passenger> getPassengers() {
		
		return dao.findAll();
	}

	@Override
	public Passenger getPassenger(int pid) {
		
		Optional<Passenger> optional=dao.findById(pid);
		
		if(optional.isPresent())
		{
			return optional.get();
		}	
				
		return null;
	}

}
