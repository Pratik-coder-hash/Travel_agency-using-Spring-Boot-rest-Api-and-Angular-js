package com.traveller.services;

import java.util.List;

import com.traveller.pojos.Passenger;

public interface PassengerService {

	public void addPassenger(Passenger pass);
	public List<Passenger> getPassengers();
	public Passenger getPassenger(int pid);
	
}
