package com.traveller.daos;



import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.traveller.pojos.TravellerSchedule;;

@Repository
public interface TravellerScheduleDao extends JpaRepository<TravellerSchedule, Integer> {
	
	String query2="From TravellerSchedule t where t.source=?1 and t.destination=?2 and t.traveller_date=?3 and t.traveller_status='On Time'";
	
	@Query(query2)
	public ArrayList<TravellerSchedule> search(@Param("src") String source, @Param("dstn") String destination, @Param("date") String date);
}
