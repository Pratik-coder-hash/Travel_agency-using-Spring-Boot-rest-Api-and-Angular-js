package com.traveller.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class UserCredentials {

	@Id
	@Column(length=10)
	private String mobile_no;
	private String password;
	private String role;
	
	public UserCredentials() {
	
	}

	public UserCredentials(String mobile_no, String password, String role) {
		super();
		this.mobile_no = mobile_no;
		this.password = password;
		this.role = role;
	}

	public String getMobile_no() {
		return mobile_no;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "UserCredentials [mobile_no=" + mobile_no + ", password=" + password + ", role=" + role + "]";
	}

	
	
	
}
