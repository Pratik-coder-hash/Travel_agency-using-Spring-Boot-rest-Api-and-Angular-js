package com.traveller.pojos;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class UserDetails {

	@SequenceGenerator(name = "User_sequence_generator",sequenceName = "User_Sequence" ,initialValue = 1 ,allocationSize = 1)
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "User_sequence_generator")
	private int userid;
	
	private String first_name;
	private String last_name;
	private String mobile_no;
	private String email;
	private String gender;
	private String city;
	private String state;
	private String password;
	
	public UserDetails() {
		
	}

	public UserDetails(String first_name, String last_name, String mobile_no, String email, String gender, String city,
			String state, String password) {
		super();
		this.first_name = first_name;
		this.last_name = last_name;
		this.mobile_no = mobile_no;
		this.email = email;
		this.gender = gender;
		this.city = city;
		this.state = state;
		this.password = password;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getMobile_no() {
		return mobile_no;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "UserDetails [userid=" + userid + ", first_name=" + first_name + ", last_name=" + last_name
				+ ", mobile_no=" + mobile_no + ", email=" + email + ", gender=" + gender + ", city=" + city + ", state="
				+ state + ", password=" + password + "]";
	}
	
	
	
	 
	
}