package com.traveller.services;

import java.util.List;

import com.traveller.pojos.Traveller;

public interface TravellerService {

	public void add(Traveller charge);
	public void delete(int tid);
	public Traveller getTraveller(int tid);
	public List<Traveller> getAllTraveller();
	public List<String> tList();

}
