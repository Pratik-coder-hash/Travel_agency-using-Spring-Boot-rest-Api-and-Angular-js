package com.traveller.daos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.traveller.pojos.Traveller;

@Repository
public interface TravellerDao extends JpaRepository<Traveller, Integer> {
	
	@Query("select tnumber from Traveller")
	public List<String> getNumber();
	

}
