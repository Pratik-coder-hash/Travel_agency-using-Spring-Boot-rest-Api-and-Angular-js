package com.traveller.services;

import com.traveller.pojos.UserDetails;

public interface UserDetailsService {

	public void addUser(UserDetails ud);
	
}
