package com.traveller.pojos;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Passenger {

	@SequenceGenerator(name = "Passenger_sequence_generator",sequenceName = "Passenger_Sequence" ,initialValue = 1 ,allocationSize = 1)

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "Passenger_sequence_generator")
	private int pid;
	
	private String username;
	private String name;
	private int age;
	private String mobile_no;
	
	public Passenger() {
		
	}

	public Passenger(String username, String name, int age, String mobile_no) {
		super();
		this.username = username;
		this.name = name;
		this.age = age;
		this.mobile_no = mobile_no;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getMobile_no() {
		return mobile_no;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	@Override
	public String toString() {
		return "Passenger [pid=" + pid + ", username=" + username + ", name=" + name + ", age=" + age + ", mobile_no="
				+ mobile_no + "]";
	}

	
	
	
}
