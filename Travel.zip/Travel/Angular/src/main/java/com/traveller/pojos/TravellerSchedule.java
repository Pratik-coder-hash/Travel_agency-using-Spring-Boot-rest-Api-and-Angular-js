package com.traveller.pojos;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class TravellerSchedule {

	@SequenceGenerator(name = "Travellerschedule_sequence_generator",sequenceName = "Travellerschedule_Sequence" ,initialValue = 1 ,allocationSize = 1)

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "Travellerschedule_sequence_generator")
	private int tsid;
	
	private String traveller_date;
	private String starting_time;
	private String ending_time;
	private String traveller_status="On Time";
	private String source;
	private String destination;
	private String cost;
	private String tnumber;
	private int capacity;
	
	public TravellerSchedule() {
		// TODO Auto-generated constructor stub
	}

	public TravellerSchedule( String traveller_date, String starting_time, String ending_time,
			String traveller_status, String source, String destination, String cost, String tnumber, int capacity) {
		super();
		
		this.traveller_date = traveller_date;
		this.starting_time = starting_time;
		this.ending_time =ending_time;
		this.traveller_status = traveller_status;
		this.source = source;
		this.destination = destination;
		this.cost = cost;
		this.tnumber = tnumber;
		this.capacity = capacity;
	}

	public int getTsid() {
		return tsid;
	}

	public void setTsid(int tsid) {
		this.tsid = tsid;
	}

	public String getTraveller_date() {
		return traveller_date;
	}

	public void setTraveller_date(String traveller_date) {
		this.traveller_date = traveller_date;
	}

	public String getStarting_time() {
		return starting_time;
	}

	public void setStarting_time(String starting_time) {
		this.starting_time = starting_time;
	}

	public String getEnding_time() {
		return ending_time;
	}

	public void setEnding_time(String ending_time) {
		this.ending_time = ending_time;
	}

	public String getTraveller_status() {
		return traveller_status;
	}

	public void setTraveller_status(String traveller_status) {
		this.traveller_status = traveller_status;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	public String getTnumber() {
		return tnumber;
	}

	public void setTnumber(String tnumber) {
		this.tnumber = tnumber;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	@Override
	public String toString() {
		return "TravelSchedule [tsid=" + tsid + ", Traveller_date=" + traveller_date + ", starting_time="
				+ starting_time + ", ending_time=" + ending_time + ", Traveller_status=" + traveller_status
				+ ", source=" + source + ", destination=" + destination + ", cost=" + cost + ", tnumber=" + tnumber
				+ ", capacity=" + capacity + "]";
	}

}
			