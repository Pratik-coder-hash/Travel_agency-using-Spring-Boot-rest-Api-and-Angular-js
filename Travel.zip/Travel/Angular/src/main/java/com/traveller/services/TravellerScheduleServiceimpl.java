package com.traveller.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.traveller.daos.TravellerScheduleDao;
import com.traveller.pojos.TravellerSchedule;

@Service
public class TravellerScheduleServiceimpl  implements TravellerScheduleService{

	@Autowired
	private TravellerScheduleDao dao;
	
	@Override
	public void addTravellerSchedule(TravellerSchedule schedule) {
		dao.save(schedule);
		
		
	}

	@Override
	public void deleteTravellerSchedule(int t_id) {
		dao.deleteById(t_id);
		
	}

	@Override
	public TravellerSchedule getTravellerSchedule(int t_id) {
		Optional<TravellerSchedule> optional=dao.findById(t_id);
		
		if(optional.isPresent())
		{
			return optional.get();
		}
		
		return null;
	}

	@Override
	public List<TravellerSchedule> getAllSchedule() {
		
		return dao.findAll();
	}


	@Override
	public TravellerSchedule updateStatus(int tsid,TravellerSchedule sc) {
		sc.setTsid(tsid);
		return dao.save(sc);
		
	}

	

	
	@Override
	public ArrayList<TravellerSchedule> Search(String source,String destination, String date) {
		return dao.search(source, destination, date);
		
		
		
	}

	

}
