package com.traveller.services;

import java.util.ArrayList;
import java.util.List;

import com.traveller.pojos.TravellerSchedule;

public interface TravellerScheduleService {

	public void addTravellerSchedule(TravellerSchedule schedule);
	public void deleteTravellerSchedule(int t_id);
	public TravellerSchedule getTravellerSchedule(int t_id);
	public List<TravellerSchedule> getAllSchedule();
	
	public TravellerSchedule updateStatus(int tsid,TravellerSchedule sc);
	public ArrayList<TravellerSchedule> Search(String source,String destination,String date);
	
}
