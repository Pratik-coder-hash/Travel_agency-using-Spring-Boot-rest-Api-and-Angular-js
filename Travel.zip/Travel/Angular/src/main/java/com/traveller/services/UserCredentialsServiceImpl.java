package com.traveller.services;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import com.traveller.daos.UserCredentialsDao;
import com.traveller.pojos.UserCredentials;

@Service
public class UserCredentialsServiceImpl implements UserCredentialsService{

	@Autowired
	private UserCredentialsDao dao;
	
	@Override
	public UserCredentials authenticate(String mobile_no, String password) {
		
		UserCredentials user=new UserCredentials();
		
		user.setMobile_no(mobile_no);
		user.setPassword(password);
		
		Example<UserCredentials> example=Example.of(user);
		Optional<UserCredentials> optional=dao.findOne(example);
		
		if(optional.isPresent())
		{
			return optional.get();
		}
		
		
		return null;
	}

	
	@Override
	public void addCredentials(UserCredentials user) {
		dao.save(user);
		
	}

	
}
