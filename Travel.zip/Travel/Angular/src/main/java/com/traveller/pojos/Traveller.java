package com.traveller.pojos;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Traveller {

	@SequenceGenerator(name = "Traveller_sequence_generator",sequenceName = "Traveller_Sequence" ,initialValue = 1000 ,allocationSize = 1)
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "Traveller_sequence_generator")
	private int tid;
	
	private String tnumber;
	private int capacity=150;
	
	public Traveller() {
		
	}

	public Traveller(String tnumber, int capacity) {
		super();
		this.tnumber = tnumber;
		this.capacity = capacity;
	}
	
	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public String getTnumber() {
		return tnumber;
	}

	public void setTnumber(String tnumber) {
		this.tnumber = tnumber;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	@Override
	public String toString() {
		return "Travellers [tid=" + tid + ", tnumber=" + tnumber + ", capacity=" + capacity + "]";
	}
	
	
	
}
