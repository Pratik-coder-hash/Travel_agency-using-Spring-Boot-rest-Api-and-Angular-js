package com.traveller.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.traveller.pojos.Response;
import com.traveller.pojos.UserCredentials;
import com.traveller.services.UserCredentialsService;

@RestController
@CrossOrigin(allowedHeaders="*")
public class User_CredentialsController {

	@Autowired
	private UserCredentialsService service;
	
	@GetMapping("/authorization/{mobile}/{password}")
	public Response validate(@PathVariable String mobile,@PathVariable String password)
	{
		try {
			
			UserCredentials user=service.authenticate(mobile, password);
			//System.out.println("user"+user);
			if(user != null) {
				return new Response("ok",200,user);
			}
			
		    }catch(Exception e) {
			e.printStackTrace();
		}
		
		return new Response("FAILED",200,null);
		
	}
	
	@PostMapping("/Credentails")
	public Response addCredentials(@RequestBody UserCredentials user)
	{

		try {
			
				service.addCredentials(user);
				return new Response("SUCCESS",200,"Added");
			
		    }catch(Exception e) {
			e.printStackTrace();
		}
		
		return new Response("FAILED",200,"Could not added");
	}
}
