package com.traveller.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.traveller.pojos.Response;
import com.traveller.pojos.UserDetails;
import com.traveller.services.UserDetailsService;

@RestController
@CrossOrigin(value = "*")
public class UserDataController {

	@Autowired
	private UserDetailsService service;
	
	@PostMapping("/UserRegistration")
	public Response addUser( @RequestBody UserDetails ud)
	{
		try
		{
			
			service.addUser(ud);
			return new Response("Success",200,"Registration done successfully");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return new Response("Failed",200,"Cannot Resgister") ;
			
		}
	}
}
