package com.traveller.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.traveller.pojos.Traveller;
import com.traveller.pojos.Response;
import com.traveller.services.TravellerService;

@RestController
@CrossOrigin(allowedHeaders="*")
public class Traveller_Controller {
	
	@Autowired
	private TravellerService service2;
	

	
	@PostMapping("/traveller")
	public Response addTraveller(@RequestBody Traveller Traveller)
	{
		try
		{
			service2.add(Traveller);
			return new Response("Success",200,"Traveller added successfully");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return new Response("Failed",200,"Traveller could not be Added");
			
		}
		
	}
	

	@DeleteMapping("/traveller/{id}")
	public String deletetraveller(@PathVariable("id") int tid)
	{
		try
		{
			service2.delete(tid);
			return "Traveller removed successfully";
		}
		catch(Exception e)
		{
			return "could not remove Traveller";	
		}
		
	}
	
	@GetMapping("/traveller/{id}")
	public Response gettravellerById(@PathVariable("id") int tid)
	{
		try
		{
			Traveller temp=service2.getTraveller(tid);
			return new Response("successful", 200, temp);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return new Response("failed", 400, null);			
		}		
	}
	
	
	@GetMapping("/travellers")
	public List<Traveller> getAllTraveller()
	{
		return service2.getAllTraveller();
		
	}
	
	
	@GetMapping("/travellerlist")
	public List<String> getAllT()
	{
		return service2.tList();
	}
	
	

}
